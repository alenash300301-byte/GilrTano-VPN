package com.gilrtano.vpn

import android.net.VpnService
import android.content.Intent

/**
 * VPN service shell. A real packet engine must be attached before establishing
 * a TUN interface; this intentionally does not create a fake/blackhole tunnel.
 */
class GilrTanoVpnService : VpnService() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf(startId)
        return START_NOT_STICKY
    }
}
