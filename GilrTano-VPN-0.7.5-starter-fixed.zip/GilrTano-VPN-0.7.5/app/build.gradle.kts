plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.gilrtano.vpn"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gilrtano.vpn"
        minSdk = 26
        targetSdk = 35
        versionCode = 75
        versionName = "0.7.5"
    }
}
