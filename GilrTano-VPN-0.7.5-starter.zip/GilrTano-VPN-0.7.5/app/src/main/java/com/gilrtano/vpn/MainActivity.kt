package com.gilrtano.vpn

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val requestCode = 4107
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28,48,28,24)
            setBackgroundColor(Color.rgb(16,24,32))
        }
        fun label(s:String, size:Float, color:Int=Color.WHITE)=TextView(this).apply {
            text=s; textSize=size; setTextColor(color); setPadding(0,12,0,12)
        }
        layout.addView(label("GilrTano VPN",30f))
        layout.addView(label("PRIVATE CONNECTION • 0.7.5",12f,0xFF80CBC4.toInt()))
        status=label("Отключено",20f)
        layout.addView(status)
        val connect=Button(this).apply { text="ПОДКЛЮЧИТЬ VPN"; setOnClickListener { requestVpn() } }
        layout.addView(connect)
        val import=Button(this).apply { text="Импортировать VLESS-ссылку"; setOnClickListener {
            val e=EditText(this).apply { hint="vless://…"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
            AlertDialog.Builder(this).setTitle("Импорт конфигурации").setView(e)
                .setPositiveButton("Сохранить") { _,_ ->
                    val value=e.text.toString().trim()
                    if(value.startsWith("vless://")) {
                        getSharedPreferences("profile",0).edit().putString("vless",value).apply()
                        Toast.makeText(this,"Ссылка сохранена локально",Toast.LENGTH_SHORT).show()
                    } else Toast.makeText(this,"Нужна ссылка vless://",Toast.LENGTH_LONG).show()
                }.setNegativeButton("Отмена",null).show()
        } }
        layout.addView(import)
        layout.addView(label("Ядро Xray ещё не подключено. Импорт профиля сохраняет ссылку, но сам по себе не запускает туннель.",14f,0xFFFFCC80.toInt()))
        layout.addView(label("Без рекламы • Локальное хранение профиля",12f,0xFFB0BEC5.toInt()))
        setContentView(layout)
    }
    private fun requestVpn() {
        val intent=VpnService.prepare(this)
        if(intent!=null) startActivityForResult(intent,requestCode)
        else onActivityResult(requestCode,RESULT_OK,null)
    }
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if(req==requestCode && res==RESULT_OK) {
            status.text="Разрешение Android получено"
            Toast.makeText(this,"VPN-разрешение выдано. Для туннеля требуется Xray-core.",Toast.LENGTH_LONG).show()
        }
    }
}
